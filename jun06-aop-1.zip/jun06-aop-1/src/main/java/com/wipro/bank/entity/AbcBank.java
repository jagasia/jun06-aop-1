package com.wipro.bank.entity;

public class AbcBank {
	public void deposit()
	{
		System.out.println("Deposited amount is credited to your account. You will get a SMS confirmation.");
	}
	
	public void withdrawal()
	{
		System.out.println("Remember to collect the cash. To save trees, do not print receipt.");
	}
}
