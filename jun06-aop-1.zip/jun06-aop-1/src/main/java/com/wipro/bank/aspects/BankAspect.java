package com.wipro.bank.aspects;

public class BankAspect {
	public void beforeAdvice()
	{
		System.out.println("Before advice working now...");
	}
	
	public void afterAdvice()
	{
		System.out.println("After advice is working now...");
	}
}
